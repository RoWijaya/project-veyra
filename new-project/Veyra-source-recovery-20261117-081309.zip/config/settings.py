import os
from pathlib import Path

import django

BASE_DIR = Path(__file__).resolve().parent.parent
try:
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def env_bool(name, default=False):
    return os.environ.get(name, str(default)).lower() in {"1", "true", "yes"}


SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-only-insecure-key-change-before-deploy")
DEBUG = env_bool("DJANGO_DEBUG", True)
if not DEBUG and (
    SECRET_KEY == "dev-only-insecure-key-change-before-deploy" or len(SECRET_KEY) < 40
):
    raise RuntimeError("Set a strong DJANGO_SECRET_KEY before running with DJANGO_DEBUG=false.")
ALLOWED_HOSTS = [
    host.strip() for host in os.getenv("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",")
]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "core.apps.CoreConfig",
]
try:
    import channels  # noqa: F401

    INSTALLED_APPS.append("channels")
except ImportError:
    pass

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "core.middleware.SecurityHeadersMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]
ROOT_URLCONF = "config.urls"
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ]
        },
    }
]
WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

if env_bool("DJANGO_SQLITE_TEST", False):
    DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}}
else:
    db_url = os.getenv("DATABASE_URL", "postgresql://veyra:veyra@localhost:5432/veyra")
    from urllib.parse import unquote, urlparse

    parsed = urlparse(db_url)
    if parsed.scheme not in {"postgres", "postgresql"}:
        raise RuntimeError(
            "DATABASE_URL must use PostgreSQL. Set DJANGO_SQLITE_TEST=1 only for tests."
        )
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": parsed.path.lstrip("/"),
            "USER": unquote(parsed.username or ""),
            "PASSWORD": unquote(parsed.password or ""),
            "HOST": parsed.hostname or "localhost",
            "PORT": parsed.port or 5432,
            "CONN_MAX_AGE": 60,
            "OPTIONS": {"connect_timeout": 5},
        }
    }

AUTH_USER_MODEL = "core.User"
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]
AUTHENTICATION_BACKENDS = ["django.contrib.auth.backends.ModelBackend"]
LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "workspace_home"
LOGOUT_REDIRECT_URL = "home"
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Jakarta"
USE_I18N = True
USE_TZ = True
STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
PAYMENT_CREDENTIALS_ENCRYPTION_KEY = os.getenv("PAYMENT_CREDENTIALS_ENCRYPTION_KEY", "")
DEFAULT_FROM_EMAIL = os.getenv("DEFAULT_FROM_EMAIL", "Veyra <accounts@veyra.app>")
MAIL_HOST = os.getenv("EMAIL_HOST", "localhost")
MAIL_PORT = int(os.getenv("EMAIL_PORT", "1025"))
MAIL_USERNAME = os.getenv("EMAIL_HOST_USER", "")
MAIL_PASSWORD = os.getenv("EMAIL_HOST_PASSWORD", "")
MAIL_USE_TLS = env_bool("EMAIL_USE_TLS")
MAIL_USE_SSL = env_bool("EMAIL_USE_SSL")
if MAIL_USE_TLS and MAIL_USE_SSL:
    raise RuntimeError("Use either EMAIL_USE_TLS or EMAIL_USE_SSL, not both.")
MAIL_BACKEND = (
    "django.core.mail.backends.console.EmailBackend"
    if DEBUG
    else "django.core.mail.backends.smtp.EmailBackend"
)
if django.VERSION >= (6, 1):
    MAILERS = {
        "default": {
            "BACKEND": MAIL_BACKEND,
            "OPTIONS": {}
            if DEBUG
            else {
                "host": MAIL_HOST,
                "port": MAIL_PORT,
                "username": MAIL_USERNAME,
                "password": MAIL_PASSWORD,
                "use_tls": MAIL_USE_TLS,
                "use_ssl": MAIL_USE_SSL,
            },
        }
    }
else:
    EMAIL_BACKEND = MAIL_BACKEND
    EMAIL_HOST = MAIL_HOST
    EMAIL_PORT = MAIL_PORT
    EMAIL_HOST_USER = MAIL_USERNAME
    EMAIL_HOST_PASSWORD = MAIL_PASSWORD
    EMAIL_USE_TLS = MAIL_USE_TLS
    EMAIL_USE_SSL = MAIL_USE_SSL
if not DEBUG:
    MIDDLEWARE.insert(1, "whitenoise.middleware.WhiteNoiseMiddleware")
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_AGE = 60 * 60 * 12
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
CSRF_COOKIE_SAMESITE = "Lax"
if not DEBUG:
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_SSL_REDIRECT = True
    SECURE_HSTS_SECONDS = 3600
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_REFERRER_POLICY = "same-origin"
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    STORAGES = {
        "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
        "staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"},
    }

if "channels" in INSTALLED_APPS:
    if env_bool("DJANGO_SQLITE_TEST", False):
        CHANNEL_LAYERS = {"default": {"BACKEND": "channels.layers.InMemoryChannelLayer"}}
    else:
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        CHANNEL_LAYERS = {
            "default": {
                "BACKEND": "channels_redis.core.RedisChannelLayer",
                "CONFIG": {"hosts": [redis_url]},
            }
        }

if not DEBUG:
    CACHES = {
        "default": {
            "BACKEND": "django.core.cache.backends.redis.RedisCache",
            "LOCATION": os.getenv("REDIS_URL", "redis://localhost:6379/1"),
            "KEY_PREFIX": "veyra",
        }
    }
