from django.contrib.auth import views as auth_views
from django.urls import path

from . import device_views, views

urlpatterns = [
    path("", views.home, name="home"),
    path("media/landing-film/", views.landing_film, name="landing_film"),
    path("healthz/", views.healthz, name="healthz"),
    path("register/", views.register, name="register"),
    path("login/", views.sign_in, name="login"),
    path("logout/", views.sign_out, name="logout"),
    path("verify/<str:uidb64>/<str:token>/", views.verify_email, name="verify_email"),
    path(
        "password-reset/",
        auth_views.PasswordResetView.as_view(
            template_name="core/auth.html", email_template_name="core/password_reset_email.html"
        ),
        name="password_reset",
    ),
    path(
        "password-reset/done/",
        auth_views.PasswordResetDoneView.as_view(template_name="core/status.html"),
        name="password_reset_done",
    ),
    path(
        "password-reset/<uidb64>/<token>/",
        auth_views.PasswordResetConfirmView.as_view(template_name="core/auth.html"),
        name="password_reset_confirm",
    ),
    path(
        "password-reset/complete/",
        auth_views.PasswordResetCompleteView.as_view(template_name="core/status.html"),
        name="password_reset_complete",
    ),
    path("app/", views.workspace_home, name="workspace_home"),
    path("app/business/new/", views.create_business_view, name="create_business"),
    path("app/<slug:slug>/", views.business_dashboard, name="business_dashboard"),
    path("app/<slug:slug>/reports/", views.reports, name="reports"),
    path("app/<slug:slug>/catalog/", views.catalog, name="catalog"),
    path("app/<slug:slug>/promotions/", views.promotions, name="promotions"),
    path(
        "app/<slug:slug>/promotions/<int:promotion_id>/edit/",
        views.promotions,
        name="promotion_edit",
    ),
    path("app/<slug:slug>/pos/", views.point_of_sale, name="point_of_sale"),
    path(
        "app/<slug:slug>/orders/<uuid:order_id>/payment/",
        views.record_payment,
        name="record_payment",
    ),
    path(
        "app/<slug:slug>/orders/<uuid:order_id>/status/",
        views.update_order_status,
        name="update_order_status",
    ),
    path("app/<slug:slug>/locations/", views.locations, name="locations"),
    path("app/<slug:slug>/tables/", views.tables, name="tables"),
    path("app/<slug:slug>/customers/", views.customers, name="customers"),
    path("app/<slug:slug>/inventory/", views.inventory, name="inventory"),
    path("app/<slug:slug>/recipes/", views.recipes, name="recipes"),
    path("app/<slug:slug>/team/", views.team, name="team"),
    path("app/<slug:slug>/stations/", views.stations, name="stations"),
    path(
        "app/<slug:slug>/stations/<uuid:station_id>/screen/",
        views.station_screen,
        name="station_screen",
    ),
    path("app/<slug:slug>/payments/", views.payment_settings, name="payment_settings"),
    path("api/stations/pair/", device_views.pair_device, name="station_pair"),
    path(
        "api/stations/<uuid:station_id>/rotate-token/",
        device_views.station_rotate_token,
        name="station_rotate_token",
    ),
    path(
        "api/stations/<uuid:station_id>/catalog/",
        device_views.station_catalog,
        name="station_catalog",
    ),
    path(
        "api/stations/<uuid:station_id>/orders/",
        device_views.station_orders,
        name="station_orders",
    ),
    path(
        "api/stations/<uuid:station_id>/orders/create/",
        device_views.station_create_order,
        name="station_create_order",
    ),
    path(
        "api/stations/<uuid:station_id>/orders/<uuid:order_id>/status/",
        device_views.station_update_order,
        name="station_update_order",
    ),
    path(
        "api/stations/<uuid:station_id>/orders/<uuid:order_id>/reprint/",
        device_views.station_reprint_order,
        name="station_reprint_order",
    ),
    path(
        "api/stations/<uuid:station_id>/orders/<uuid:order_id>/pay/",
        device_views.station_initiate_payment,
        name="station_initiate_payment",
    ),
    path(
        "api/stations/<uuid:station_id>/print-jobs/",
        device_views.station_print_jobs,
        name="station_print_jobs",
    ),
    path(
        "api/stations/<uuid:station_id>/print-jobs/<uuid:job_id>/ack/",
        device_views.station_ack_print_job,
        name="station_ack_print_job",
    ),
    path(
        "api/payments/webhooks/<str:provider>/",
        device_views.payment_webhook,
        name="payment_webhook",
    ),
    path("order/table/<str:token>/qr.svg", views.table_qr, name="table_qr"),
    path("order/table/<str:token>/", views.table_order, name="table_order"),
    path("order/table/<str:token>/menu.json", views.table_menu_data, name="table_menu_data"),
    path("order/<uuid:order_id>/status/", views.guest_order_tracking, name="guest_order_tracking"),
    path("order/<uuid:order_id>/payment.svg", views.guest_order_payment_qr, name="guest_order_payment_qr"),
    path(
        "invitations/<slug:slug>/<str:token>/accept/",
        views.accept_invitation_view,
        name="accept_invitation",
    ),
]
