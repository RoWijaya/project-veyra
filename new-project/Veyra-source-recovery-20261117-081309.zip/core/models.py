import uuid

from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.db import models


def all_weekdays():
    return list(range(7))


def default_plan_entitlements():
    return {
        "features": [
            "catalog", "pos", "qr_ordering", "inventory", "promotions",
            "analytics", "payments", "team", "stations",
        ],
        "limits": {},
    }


class UserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Email is required")
        user = self.model(email=self.normalize_email(email).lower(), **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)
        return self.create_user(email, password, **extra_fields)


class User(AbstractUser):
    username = None
    email = models.EmailField(unique=True)
    email_verified_at = models.DateTimeField(null=True, blank=True)
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []
    objects = UserManager()

    def save(self, *args, **kwargs):
        self.email = self.email.strip().lower()
        return super().save(*args, **kwargs)


class Business(models.Model):
    class Type(models.TextChoices):
        CAFE = "cafe", "Café"
        RESTAURANT = "restaurant", "Restaurant"
        BAKERY = "bakery", "Bakery"
        BAR = "bar", "Bar"
        RETAIL = "retail", "Retail"
        OTHER = "other", "Other"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    owner = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.PROTECT, related_name="owned_businesses"
    )
    name = models.CharField(max_length=160)
    slug = models.SlugField(max_length=180, unique=True)
    business_type = models.CharField(max_length=40, choices=Type.choices, default=Type.OTHER)
    timezone_name = models.CharField(max_length=64, default="Asia/Jakarta")
    created_at = models.DateTimeField(auto_now_add=True)


class Membership(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="memberships")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="memberships")
    permissions = models.JSONField(default=list, blank=True)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["business", "user"], name="uniq_business_member"),
        ]

    def allows(self, permission):
        return self.business.owner_id == self.user_id or permission in self.permissions


class SubscriptionPlan(models.Model):
    code = models.SlugField(unique=True)
    name = models.CharField(max_length=100)
    monthly_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=3, default="IDR")
    trial_days = models.PositiveSmallIntegerField(default=0)
    entitlements = models.JSONField(default=default_plan_entitlements)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class BusinessSubscription(models.Model):
    class Status(models.TextChoices):
        TRIAL = "trial", "Trial"
        ACTIVE = "active", "Active"
        PAST_DUE = "past_due", "Past due"
        CANCELED = "canceled", "Canceled"
        EXPIRED = "expired", "Expired"
        GRANDFATHERED = "grandfathered", "Grandfathered access"

    business = models.OneToOneField(
        Business, on_delete=models.PROTECT, related_name="subscription"
    )
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.PROTECT, related_name="subscriptions")
    status = models.CharField(max_length=16, choices=Status.choices)
    trial_started_at = models.DateTimeField(null=True, blank=True)
    trial_ends_at = models.DateTimeField(null=True, blank=True)
    current_period_start = models.DateTimeField(null=True, blank=True)
    current_period_end = models.DateTimeField(null=True, blank=True)
    canceled_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class AppendOnlySubscriptionEventQuerySet(models.QuerySet):
    def update(self, **kwargs):
        raise ValueError("Subscription events are append-only")

    def delete(self):
        raise ValueError("Subscription events are append-only")

    def bulk_update(self, objs, fields, **kwargs):
        raise ValueError("Subscription events are append-only")


class SubscriptionEvent(models.Model):
    objects = AppendOnlySubscriptionEventQuerySet.as_manager()
    subscription = models.ForeignKey(
        BusinessSubscription, on_delete=models.PROTECT, related_name="events"
    )
    actor = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    event_type = models.CharField(max_length=80)
    from_status = models.CharField(max_length=16, blank=True)
    to_status = models.CharField(max_length=16, blank=True)
    from_plan = models.CharField(max_length=80, blank=True)
    to_plan = models.CharField(max_length=80, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValueError("Subscription events are append-only")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError("Subscription events are append-only")


class Invitation(models.Model):
    business = models.ForeignKey(Business, on_delete=models.PROTECT, related_name="invitations")
    invited_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="sent_invitations")
    email = models.EmailField()
    permissions = models.JSONField(default=list, blank=True)
    token_digest = models.CharField(max_length=64, unique=True)
    expires_at = models.DateTimeField()
    accepted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["business", "email", "accepted_at"])]


class Location(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="locations")
    name = models.CharField(max_length=120)
    address = models.TextField(blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["business", "name"], name="uniq_business_location")
        ]


class DiningTable(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="tables")
    location = models.ForeignKey(Location, on_delete=models.PROTECT, related_name="tables")
    name = models.CharField(max_length=80)
    area = models.CharField(max_length=80, blank=True)
    qr_version = models.UUIDField(default=uuid.uuid4, editable=False)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["business", "location", "name"], name="uniq_table_location_name"
            )
        ]

    def clean(self):
        if self.location_id and self.location.business_id != self.business_id:
            raise ValidationError({"location": "Location must belong to this business."})


class Department(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="departments")
    name = models.CharField(max_length=80)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["business", "name"], name="uniq_business_department")
        ]


class Workspace(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="workspaces")
    location = models.ForeignKey(
        Location, null=True, blank=True, on_delete=models.PROTECT, related_name="workspaces"
    )
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=100)
    active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["business", "name"], name="uniq_business_workspace")
        ]

    def clean(self):
        if self.location_id and self.location.business_id != self.business_id:
            raise ValidationError({"location": "Location must belong to this business."})
        if self.department_id and self.department.business_id != self.business_id:
            raise ValidationError({"department": "Department must belong to this business."})


class WorkspaceAssignment(models.Model):
    membership = models.ForeignKey(
        Membership, on_delete=models.CASCADE, related_name="workspace_assignments"
    )
    workspace = models.ForeignKey(Workspace, on_delete=models.CASCADE, related_name="assignments")
    permissions = models.JSONField(default=list, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["membership", "workspace"], name="uniq_workspace_assignment"
            )
        ]

    def clean(self):
        if (
            self.membership_id
            and self.workspace_id
            and self.membership.business_id != self.workspace.business_id
        ):
            raise ValidationError("Membership and workspace must belong to the same business.")


class Printer(models.Model):
    class PrinterType(models.TextChoices):
        NETWORK_ESCPOS = "network_escpos", "Network ESC/POS"
        USB_ESCPOS = "usb_escpos", "USB ESC/POS"
        VIRTUAL = "virtual", "Virtual / Browser"

    class Status(models.TextChoices):
        ONLINE = "online", "Online"
        OFFLINE = "offline", "Offline"
        UNKNOWN = "unknown", "Unknown"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="printers")
    location = models.ForeignKey(
        Location, null=True, blank=True, on_delete=models.SET_NULL, related_name="printers"
    )
    name = models.CharField(max_length=100)
    printer_type = models.CharField(
        max_length=32, choices=PrinterType.choices, default=PrinterType.NETWORK_ESCPOS
    )
    connection_params = models.JSONField(default=dict, blank=True)
    paper_width = models.CharField(max_length=10, default="80mm")
    is_active = models.BooleanField(default=True)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.UNKNOWN)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["business", "name"], name="uniq_business_printer")
        ]

    def clean(self):
        if self.location_id and self.location.business_id != self.business_id:
            raise ValidationError({"location": "Location must belong to this business."})


class Station(models.Model):
    class Kind(models.TextChoices):
        REGISTER = "register", "Register"
        KITCHEN = "kitchen", "Kitchen"
        BAR = "bar", "Bar"
        CUSTOM = "custom", "Custom"

    class HandlingMode(models.TextChoices):
        BOTH = "both", "Digital KDS & Printed Tickets"
        KDS = "kds", "Digital KDS Only"
        PRINTED = "printed", "Printed Tickets Only"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="stations")
    location = models.ForeignKey(
        Location, null=True, blank=True, on_delete=models.PROTECT, related_name="stations"
    )
    name = models.CharField(max_length=100)
    kind = models.CharField(max_length=16, choices=Kind.choices, default=Kind.CUSTOM)
    handling_mode = models.CharField(
        max_length=20, choices=HandlingMode.choices, default=HandlingMode.BOTH
    )
    printer = models.ForeignKey(
        Printer, null=True, blank=True, on_delete=models.SET_NULL, related_name="stations"
    )
    capabilities = models.JSONField(default=list, blank=True)
    active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["business", "name"], name="uniq_business_station")
        ]

    def clean(self):
        if self.location_id and self.location.business_id != self.business_id:
            raise ValidationError({"location": "Location must belong to this business."})
        if self.printer_id and self.printer.business_id != self.business_id:
            raise ValidationError({"printer": "Printer must belong to this business."})


class StationPairingCode(models.Model):
    station = models.ForeignKey(Station, on_delete=models.CASCADE, related_name="pairing_codes")
    issued_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    code_digest = models.CharField(max_length=64, unique=True)
    expires_at = models.DateTimeField()
    consumed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class PairedDevice(models.Model):
    station = models.ForeignKey(Station, on_delete=models.CASCADE, related_name="devices")
    label = models.CharField(max_length=120)
    token_digest = models.CharField(max_length=64, unique=True)
    paired_at = models.DateTimeField(auto_now_add=True)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=["station", "revoked_at"])]


class PaymentConnection(models.Model):
    class Provider(models.TextChoices):
        MIDTRANS = "midtrans", "Midtrans"
        BCA_QRIS = "bca_qris", "BCA QRIS (SNAP)"

    class Environment(models.TextChoices):
        SANDBOX = "sandbox", "Sandbox"
        PRODUCTION = "production", "Production"

    business = models.ForeignKey(
        Business, on_delete=models.CASCADE, related_name="payment_connections"
    )
    provider = models.CharField(max_length=24, choices=Provider.choices)
    environment = models.CharField(max_length=16, choices=Environment.choices)
    merchant_id = models.CharField(max_length=120)
    credentials_ciphertext = models.TextField()
    verified_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["business", "provider"], name="uniq_business_payment_provider"
            )
        ]


class Category(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="categories")
    name = models.CharField(max_length=100)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "name"]
        constraints = [
            models.UniqueConstraint(fields=["business", "name"], name="uniq_business_category")
        ]


class Product(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="products")
    category = models.ForeignKey(
        Category, null=True, blank=True, on_delete=models.SET_NULL, related_name="products"
    )
    station = models.ForeignKey(
        Station, null=True, blank=True, on_delete=models.SET_NULL, related_name="routed_products"
    )
    name = models.CharField(max_length=160)
    sku = models.CharField(max_length=80, blank=True)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=models.Q(price__gte=0), name="product_price_nonnegative"
            )
        ]
        indexes = [models.Index(fields=["business", "active", "name"])]

    def clean(self):
        if self.category_id and self.category.business_id != self.business_id:
            raise ValidationError({"category": "Category must belong to this business."})
        if self.station_id and self.station.business_id != self.business_id:
            raise ValidationError({"station": "Station must belong to this business."})


class Promotion(models.Model):
    class DiscountType(models.TextChoices):
        FIXED_PRICE = "fixed_price", "Promotional price"
        PERCENT = "percent", "Percentage off"
        FIXED_AMOUNT = "fixed_amount", "Amount off"

    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="promotions")
    name = models.CharField(max_length=120)
    section = models.CharField(max_length=80, blank=True)
    active = models.BooleanField(default=True)
    starts_at = models.DateTimeField(null=True, blank=True)
    ends_at = models.DateTimeField(null=True, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    start_time = models.TimeField(null=True, blank=True)
    end_time = models.TimeField(null=True, blank=True)
    days_of_week = models.JSONField(default=all_weekdays)
    discount_type = models.CharField(max_length=16, choices=DiscountType.choices)
    value = models.DecimalField(max_digits=12, decimal_places=2)
    priority = models.PositiveSmallIntegerField(default=0)
    stackable = models.BooleanField(default=False)
    products = models.ManyToManyField(Product, blank=True, related_name="promotions")
    categories = models.ManyToManyField(Category, blank=True, related_name="promotions")
    locations = models.ManyToManyField(Location, blank=True, related_name="promotions")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [models.Index(fields=["business", "active", "priority"])]

    def clean(self):
        from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

        errors = {}
        try:
            ZoneInfo(self.business.timezone_name)
        except (ZoneInfoNotFoundError, AttributeError):
            errors["business"] = "The business timezone must be a valid IANA timezone."
        if self.starts_at and self.ends_at and self.ends_at <= self.starts_at:
            errors["ends_at"] = "The end timestamp must be after the start timestamp."
        if self.start_date and self.end_date and self.end_date < self.start_date:
            errors["end_date"] = "The end date must be on or after the start date."
        if bool(self.start_time) != bool(self.end_time):
            errors["end_time"] = "Set both recurring times, or leave both blank."
        if self.start_time and self.end_time and self.start_time == self.end_time:
            errors["end_time"] = "A recurring promotion cannot have a zero-length time window."
        if not isinstance(self.days_of_week, list) or any(
            type(day) is not int or day < 0 or day > 6 for day in self.days_of_week
        ):
            errors["days_of_week"] = "Choose weekdays from 0 (Monday) through 6 (Sunday)."
        if self.value is not None:
            if self.value <= 0:
                errors["value"] = "The promotion value must be greater than zero."
            elif self.discount_type == self.DiscountType.PERCENT and self.value > 100:
                errors["value"] = "Percentage discounts cannot exceed 100%."
        if self.pk and self.business_id:
            if self.products.exclude(business_id=self.business_id).exists():
                errors["products"] = "Products must belong to this business."
            if self.categories.exclude(business_id=self.business_id).exists():
                errors["categories"] = "Categories must belong to this business."
            if self.locations.exclude(business_id=self.business_id).exists():
                errors["locations"] = "Locations must belong to this business."
        if errors:
            raise ValidationError(errors)


class PromotionScheduleState(models.Model):
    promotion = models.OneToOneField(
        Promotion, on_delete=models.CASCADE, related_name="schedule_state"
    )
    is_in_window = models.BooleanField()
    checked_at = models.DateTimeField(auto_now=True)


class OrderLinePromotion(models.Model):
    line = models.ForeignKey("OrderLine", on_delete=models.CASCADE, related_name="promotions")
    promotion_name = models.CharField(max_length=120)
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)


class Customer(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="customers")
    name = models.CharField(max_length=160)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=40, blank=True)
    note = models.CharField(max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["business", "name"])]


class InventoryItem(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="inventory_items")
    name = models.CharField(max_length=160)
    sku = models.CharField(max_length=80, blank=True)
    unit = models.CharField(max_length=24)
    active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["business", "name"], name="uniq_inventory_name")
        ]


class InventoryBalance(models.Model):
    item = models.ForeignKey(InventoryItem, on_delete=models.CASCADE, related_name="balances")
    location = models.ForeignKey(
        Location, on_delete=models.PROTECT, related_name="inventory_balances"
    )
    quantity = models.DecimalField(max_digits=12, decimal_places=3, default=0)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["item", "location"], name="uniq_inventory_location_balance"
            ),
            models.CheckConstraint(
                condition=models.Q(quantity__gte=0), name="inventory_quantity_nonnegative"
            ),
        ]

    def clean(self):
        if self.item_id and self.location_id and self.item.business_id != self.location.business_id:
            raise ValidationError("Inventory item and location must belong to the same business.")


class AppendOnlyStockMovementQuerySet(models.QuerySet):
    def update(self, **kwargs):
        raise ValueError("Stock movements are append-only")

    def delete(self):
        raise ValueError("Stock movements are append-only")

    def bulk_update(self, objs, fields, **kwargs):
        raise ValueError("Stock movements are append-only")


class StockMovement(models.Model):
    objects = AppendOnlyStockMovementQuerySet.as_manager()

    class Reason(models.TextChoices):
        OPENING = "opening", "Opening stock"
        RECEIVED = "received", "Stock received"
        ADJUSTMENT = "adjustment", "Manual adjustment"
        WASTE = "waste", "Waste"
        TRANSFER = "transfer", "Transfer"
        SALE = "sale", "Recipe consumption"
        RETURN = "return", "Order cancellation return"

    business = models.ForeignKey(Business, on_delete=models.PROTECT, related_name="stock_movements")
    item = models.ForeignKey(InventoryItem, on_delete=models.PROTECT, related_name="movements")
    location = models.ForeignKey(Location, on_delete=models.PROTECT)
    order = models.ForeignKey(
        "Order", null=True, blank=True, on_delete=models.PROTECT, related_name="stock_movements"
    )
    actor = models.ForeignKey(User, null=True, on_delete=models.PROTECT)
    quantity_delta = models.DecimalField(max_digits=12, decimal_places=3)
    reason = models.CharField(max_length=16, choices=Reason.choices)
    idempotency_key = models.UUIDField(default=uuid.uuid4)
    request_digest = models.CharField(max_length=64, blank=True)
    note = models.CharField(max_length=240, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["business", "idempotency_key"], name="uniq_stock_idempotency"
            ),
            models.CheckConstraint(
                condition=~models.Q(quantity_delta=0), name="stock_movement_nonzero"
            ),
            models.UniqueConstraint(
                fields=["order", "item", "reason"],
                condition=models.Q(order__isnull=False, reason__in=["sale", "return"]),
                name="uniq_order_recipe_movement",
            ),
        ]

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValueError("Stock movements are append-only")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError("Stock movements are append-only")

    def clean(self):
        if self.item_id and self.item.business_id != self.business_id:
            raise ValidationError({"item": "Item must belong to the movement's business."})
        if self.location_id and self.location.business_id != self.business_id:
            raise ValidationError({"location": "Location must belong to the movement's business."})
        if self.order_id and self.order.business_id != self.business_id:
            raise ValidationError({"order": "Order must belong to the movement's business."})


class OutboxEvent(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(Business, on_delete=models.PROTECT, related_name="outbox_events")
    event_type = models.CharField(max_length=80)
    payload = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)
    next_attempt_at = models.DateTimeField()
    published_at = models.DateTimeField(null=True, blank=True)
    attempts = models.PositiveSmallIntegerField(default=0)
    last_error = models.CharField(max_length=300, blank=True)

    class Meta:
        indexes = [models.Index(fields=["published_at", "next_attempt_at"])]


class RecipeLine(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="recipe_lines")
    item = models.ForeignKey(InventoryItem, on_delete=models.PROTECT, related_name="recipe_lines")
    quantity = models.DecimalField(max_digits=10, decimal_places=3)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["product", "item"], name="uniq_recipe_ingredient"),
            models.CheckConstraint(
                condition=models.Q(quantity__gt=0), name="recipe_quantity_positive"
            ),
        ]

    def clean(self):
        if self.product_id and self.item_id and self.product.business_id != self.item.business_id:
            raise ValidationError("Recipe item and product must belong to the same business.")


class Order(models.Model):
    class Source(models.TextChoices):
        POS = "pos", "POS"
        TABLE_QR = "table_qr", "Table QR"
        STATION = "station", "Station"

    class OrderType(models.TextChoices):
        DINE_IN = "dine_in", "Dine in"
        TAKEAWAY = "takeaway", "Takeaway"

    class Status(models.TextChoices):
        NEW = "new", "New"
        PREPARING = "preparing", "Preparing"
        READY = "ready", "Ready"
        COMPLETED = "completed", "Completed"
        CANCELLED = "cancelled", "Cancelled"

    class PaymentMethod(models.TextChoices):
        COUNTER = "counter", "Pay at counter"
        QRIS = "qris", "QRIS"
        CASH = "cash", "Cash"
        CARD = "card", "Card"

    class PaymentStatus(models.TextChoices):
        UNPAID = "unpaid", "Unpaid"
        PENDING = "pending", "Pending"
        PAID = "paid", "Paid"
        FAILED = "failed", "Failed"
        EXPIRED = "expired", "Expired"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(Business, on_delete=models.PROTECT, related_name="orders")
    location = models.ForeignKey(Location, null=True, blank=True, on_delete=models.PROTECT)
    table = models.ForeignKey(
        DiningTable, null=True, blank=True, on_delete=models.PROTECT, related_name="orders"
    )
    created_by = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    created_by_device = models.ForeignKey(
        PairedDevice, null=True, blank=True, on_delete=models.SET_NULL, related_name="orders"
    )
    customer = models.ForeignKey(Customer, null=True, blank=True, on_delete=models.SET_NULL)
    customer_name_snapshot = models.CharField(max_length=160, blank=True)
    customer_email_snapshot = models.EmailField(blank=True)
    customer_phone_snapshot = models.CharField(max_length=40, blank=True)
    idempotency_key = models.UUIDField(default=uuid.uuid4)
    idempotency_digest = models.CharField(max_length=64, blank=True)
    order_type = models.CharField(
        max_length=16, choices=OrderType.choices, default=OrderType.TAKEAWAY
    )
    source = models.CharField(max_length=16, choices=Source.choices, default=Source.POS)
    payment_method = models.CharField(
        max_length=16, choices=PaymentMethod.choices, default=PaymentMethod.COUNTER
    )
    payment_provider = models.CharField(max_length=24, blank=True)
    payment_status = models.CharField(
        max_length=16, choices=PaymentStatus.choices, default=PaymentStatus.UNPAID
    )
    guest_tracking_digest = models.CharField(max_length=64, null=True, blank=True, unique=True)
    table_label = models.CharField(max_length=40, blank=True)
    note = models.CharField(max_length=500, blank=True)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.NEW)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["business", "idempotency_key"], name="uniq_order_idempotency"
            )
        ]
        indexes = [models.Index(fields=["business", "status", "created_at"])]


class OrderTender(models.Model):
    class Method(models.TextChoices):
        CASH = "cash", "Cash"
        CARD = "card", "Card"

    order = models.OneToOneField(Order, on_delete=models.PROTECT, related_name="tender")
    method = models.CharField(max_length=8, choices=Method.choices)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    cash_received = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    change_due = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    reference = models.CharField(max_length=120, blank=True)
    recorded_by = models.ForeignKey(User, on_delete=models.PROTECT)
    idempotency_key = models.UUIDField(default=uuid.uuid4)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.CheckConstraint(condition=models.Q(amount__gt=0), name="order_tender_amount_positive"),
            models.CheckConstraint(
                condition=(
                    models.Q(
                        method="cash",
                        cash_received__gte=models.F("amount"),
                        change_due=models.F("cash_received") - models.F("amount"),
                    )
                    | models.Q(method="card", cash_received__isnull=True, change_due=0)
                ),
                name="order_tender_payment_consistent",
            ),
        ]


class OrderLine(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="lines")
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    product_name = models.CharField(max_length=160)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    base_unit_price = models.DecimalField(max_digits=12, decimal_places=2)
    quantity = models.PositiveSmallIntegerField()

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=models.Q(quantity__gte=1), name="order_line_quantity_positive"
            )
        ]

    @property
    def line_total(self):
        return self.unit_price * self.quantity

    def clean(self):
        if self.order_id and self.product_id and self.order.business_id != self.product.business_id:
            raise ValidationError({"product": "Product must belong to the order's business."})


class AppendOnlyAuditQuerySet(models.QuerySet):
    def update(self, **kwargs):
        raise ValueError("Audit events are append-only")

    def delete(self):
        raise ValueError("Audit events are append-only")

    def bulk_update(self, objs, fields, **kwargs):
        raise ValueError("Audit events are append-only")


class AuditEvent(models.Model):
    objects = AppendOnlyAuditQuerySet.as_manager()
    business = models.ForeignKey(
        Business, null=True, blank=True, on_delete=models.PROTECT, related_name="audit_events"
    )
    actor = models.ForeignKey(User, null=True, blank=True, on_delete=models.PROTECT)
    action = models.CharField(max_length=80)
    object_type = models.CharField(max_length=80, blank=True)
    object_id = models.CharField(max_length=80, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValueError("Audit events are append-only")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError("Audit events are append-only")


class PrintJob(models.Model):
    class JobType(models.TextChoices):
        PREP_TICKET = "prep_ticket", "Preparation Ticket"
        RECEIPT = "receipt", "Customer Receipt"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        PRINTING = "printing", "Printing"
        PRINTED = "printed", "Printed"
        FAILED = "failed", "Failed"
        CANCELLED = "cancelled", "Cancelled"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name="print_jobs")
    station = models.ForeignKey(
        Station, null=True, blank=True, on_delete=models.SET_NULL, related_name="print_jobs"
    )
    printer = models.ForeignKey(
        Printer, null=True, blank=True, on_delete=models.SET_NULL, related_name="print_jobs"
    )
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="print_jobs")
    job_type = models.CharField(max_length=24, choices=JobType.choices, default=JobType.PREP_TICKET)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    ticket_payload = models.JSONField(default=dict)
    attempts = models.PositiveSmallIntegerField(default=0)
    max_attempts = models.PositiveSmallIntegerField(default=3)
    last_error = models.CharField(max_length=300, blank=True)
    idempotency_key = models.UUIDField(default=uuid.uuid4)
    created_at = models.DateTimeField(auto_now_add=True)
    printed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["business", "status", "created_at"]),
            models.Index(fields=["station", "status"]),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["business", "idempotency_key"], name="uniq_print_job_idempotency"
            )
        ]


class PaymentTransaction(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        PAID = "paid", "Paid"
        EXPIRED = "expired", "Expired"
        FAILED = "failed", "Failed"
        REFUNDED = "refunded", "Refunded"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(
        Business, on_delete=models.CASCADE, related_name="payment_transactions"
    )
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="payments")
    connection = models.ForeignKey(
        PaymentConnection, on_delete=models.PROTECT, related_name="transactions"
    )
    provider = models.CharField(max_length=24, choices=PaymentConnection.Provider.choices)
    environment = models.CharField(max_length=16, choices=PaymentConnection.Environment.choices)
    provider_transaction_id = models.CharField(max_length=120, blank=True, db_index=True)
    merchant_reference = models.CharField(max_length=120, blank=True, db_index=True)
    idempotency_key = models.UUIDField(default=uuid.uuid4)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    currency = models.CharField(max_length=8, default="IDR")
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.PENDING)
    qr_payload = models.TextField(blank=True)
    qr_image_url = models.URLField(max_length=500, blank=True)
    expires_at = models.DateTimeField()
    paid_at = models.DateTimeField(null=True, blank=True)
    raw_response = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=["business", "status", "created_at"]),
            models.Index(fields=["order", "status"]),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["business", "idempotency_key"], name="uniq_payment_tx_idempotency"
            )
        ]


class AppendOnlyWebhookEventQuerySet(models.QuerySet):
    def update(self, **kwargs):
        raise ValueError("Webhook events are append-only")

    def delete(self):
        raise ValueError("Webhook events are append-only")

    def bulk_update(self, objs, fields, **kwargs):
        raise ValueError("Webhook events are append-only")


class PaymentWebhookEvent(models.Model):
    objects = AppendOnlyWebhookEventQuerySet.as_manager()

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    business = models.ForeignKey(
        Business, null=True, blank=True, on_delete=models.PROTECT, related_name="webhook_events"
    )
    provider = models.CharField(max_length=24)
    event_type = models.CharField(max_length=80, blank=True)
    request_digest = models.CharField(max_length=64, unique=True)
    headers = models.JSONField(default=dict)
    payload = models.JSONField(default=dict)
    is_valid_signature = models.BooleanField(default=False)
    processed = models.BooleanField(default=False)
    error = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.pk and PaymentWebhookEvent.objects.filter(pk=self.pk).exists():
            raise ValueError("Webhook events are append-only")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValueError("Webhook events are append-only")
