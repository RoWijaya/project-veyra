from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal
from zoneinfo import ZoneInfo

from django.db.models import Q
from django.utils import timezone

from .models import Product, Promotion


@dataclass(frozen=True)
class AppliedPromotion:
    name: str
    discount_amount: Decimal


@dataclass(frozen=True)
class PriceQuote:
    base_price: Decimal
    unit_price: Decimal
    promotions: tuple[AppliedPromotion, ...] = ()

    @property
    def discount_amount(self):
        return self.base_price - self.unit_price


def _is_in_window(promotion, local_now, utc_now):
    if promotion.starts_at and utc_now < promotion.starts_at:
        return False
    if promotion.ends_at and utc_now >= promotion.ends_at:
        return False
    if promotion.start_date and local_now.date() < promotion.start_date:
        return False
    if promotion.end_date and local_now.date() > promotion.end_date:
        return False
    if not promotion.start_time:
        return True

    start, end = promotion.start_time, promotion.end_time
    current = local_now.timetz().replace(tzinfo=None)
    if start < end:
        return local_now.weekday() in promotion.days_of_week and start <= current < end
    if current >= start:
        return local_now.weekday() in promotion.days_of_week
    if current < end:
        previous_day = (local_now.weekday() - 1) % 7
        return previous_day in promotion.days_of_week
    return False


def promotion_is_in_window(promotion, *, at=None):
    now = at or timezone.now()
    if timezone.is_naive(now):
        now = timezone.make_aware(now, timezone=timezone.get_current_timezone())
    utc_now = now.astimezone(ZoneInfo("UTC"))
    local_now = utc_now.astimezone(ZoneInfo(promotion.business.timezone_name))
    return promotion.active and _is_in_window(promotion, local_now, utc_now)


def _discounted_price(current_price, promotion):
    if promotion.discount_type == Promotion.DiscountType.FIXED_PRICE:
        price = min(current_price, promotion.value)
    elif promotion.discount_type == Promotion.DiscountType.PERCENT:
        price = current_price * (Decimal("100") - promotion.value) / Decimal("100")
    else:
        price = current_price - promotion.value
    return max(Decimal("0.00"), price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def price_product(*, product, business=None, location=None, at=None):
    """Return the authoritative price using current business-local promotion rules."""
    business = business or product.business
    if product.business_id != business.pk or not product.active:
        raise Product.DoesNotExist
    now = at or timezone.now()
    if timezone.is_naive(now):
        now = timezone.make_aware(now, timezone=timezone.get_current_timezone())
    utc_now = now.astimezone(ZoneInfo("UTC"))
    local_now = utc_now.astimezone(ZoneInfo(business.timezone_name))
    target_match = Q(products=product)
    if product.category_id:
        target_match |= Q(categories_id=product.category_id)
    target_match |= Q(products__isnull=True, categories__isnull=True)
    promotions = list(
        Promotion.objects.filter(business=business, active=True)
        .filter(target_match)
        .prefetch_related("products", "categories", "locations")
        .distinct()
    )
    candidates = []
    for promotion in promotions:
        product_ids = {item.pk for item in promotion.products.all()}
        category_ids = {item.pk for item in promotion.categories.all()}
        if (
            (product_ids or category_ids)
            and product.pk not in product_ids
            and product.category_id not in category_ids
        ):
            continue
        location_ids = {item.pk for item in promotion.locations.all()}
        if location_ids and (location is None or location.pk not in location_ids):
            continue
        if not _is_in_window(promotion, local_now, utc_now):
            continue
        candidate_price = _discounted_price(product.price, promotion)
        candidates.append((promotion, candidate_price))
    if not candidates:
        return PriceQuote(base_price=product.price, unit_price=product.price)

    candidates.sort(key=lambda item: (-item[0].priority, item[1], item[0].pk))
    winner, winner_price = candidates[0]
    applied = [AppliedPromotion(winner.name, product.price - winner_price)]
    current_price = winner_price
    if winner.stackable:
        for promotion, _ in candidates[1:]:
            if not promotion.stackable:
                continue
            next_price = _discounted_price(current_price, promotion)
            if next_price < current_price:
                applied.append(AppliedPromotion(promotion.name, current_price - next_price))
                current_price = next_price
    return PriceQuote(
        base_price=product.price,
        unit_price=current_price,
        promotions=tuple(applied),
    )


def promotional_ordering(*, business, products, location=None, at=None):
    products = list(products)
    quotes = {
        product.pk: price_product(product=product, business=business, location=location, at=at)
        for product in products
    }
    for product in products:
        product.price_quote = quotes[product.pk]
        product.display_price = quotes[product.pk].unit_price
    return sorted(
        products,
        key=lambda product: (
            not bool(quotes[product.pk].promotions),
            product.category.sort_order if product.category_id else 2**31,
            product.category.name if product.category_id else "",
            product.name.casefold(),
        ),
    )
