from django.contrib import admin

from .models import BusinessSubscription, SubscriptionEvent, SubscriptionPlan


@admin.register(SubscriptionPlan)
class SubscriptionPlanAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "monthly_price", "currency", "trial_days", "active")
    list_filter = ("active", "currency")
    search_fields = ("name", "code")
    readonly_fields = ("created_at", "updated_at")


@admin.register(BusinessSubscription)
class BusinessSubscriptionAdmin(admin.ModelAdmin):
    list_display = ("business_name", "plan", "status", "trial_ends_at", "current_period_end")
    list_filter = ("status", "plan")
    search_fields = ("business__name", "business__slug")
    readonly_fields = ("created_at", "updated_at")

    @admin.display(description="Business", ordering="business__name")
    def business_name(self, obj):
        return obj.business.name

    def save_model(self, request, obj, form, change):
        previous = None
        if change:
            previous = BusinessSubscription.objects.select_related("plan").get(pk=obj.pk)
        super().save_model(request, obj, form, change)
        changed_fields = set(form.changed_data)
        changed = not previous or bool(changed_fields)
        if changed:
            SubscriptionEvent.objects.create(
                subscription=obj,
                actor=request.user,
                event_type="platform.subscription_updated" if previous else "platform.subscription_created",
                from_status=previous.status if previous else "",
                to_status=obj.status,
                from_plan=previous.plan.code if previous else "",
                to_plan=obj.plan.code,
                metadata={"source": "django_admin", "changed_fields": sorted(changed_fields)},
            )

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(SubscriptionEvent)
class SubscriptionEventAdmin(admin.ModelAdmin):
    list_display = ("subscription", "event_type", "from_status", "to_status", "created_at")
    list_filter = ("event_type", "to_status")
    search_fields = ("subscription__business__name", "event_type")
    readonly_fields = tuple(field.name for field in SubscriptionEvent._meta.fields)

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
