# System architecture

## 1. Architectural style

The inspected codebase is a **Django modular monolith**. The application is organized around one Django project (`config`) and one principal application (`core`). Business rules are concentrated in service functions in `core/services.py`; request handlers live in `core/views.py` and `core/device_views.py`; persistence is defined in `core/models.py`.

The current web interface is server-rendered with Django templates. Static interaction and presentation are implemented in `core/static/core/site.js` and `site.css`. The landing page uses GSAP/ScrollTrigger according to the existing landing workflow note.

## 2. Runtime components

| Component | Responsibility |
|---|---|
| Django HTTP application | Authentication, Management pages, POS pages, catalog, locations, customers, inventory, team, station and payment settings |
| PostgreSQL | Authoritative relational data store in normal development and production |
| Django Channels | WebSocket consumer for authorized business order updates |
| Redis | Channels layer and production Django cache/rate-limit backend |
| Outbox worker | Polls `OutboxEvent` rows and dispatches pending events to the Channels layer |
| Uvicorn / ASGI | Runs the ASGI application and HTTP/WebSocket protocols |
| WhiteNoise | Serves collected static assets when `DEBUG` is false |

## 3. Request paths

### Management browser

1. The user authenticates using Django's session-based authentication.
2. The route resolves a business slug.
3. The view obtains an active membership for that user and business, or otherwise checks canonical business ownership as implemented by the membership helper.
4. The view checks the required permission.
5. The query is scoped to the resolved business.
6. Mutations are delegated to service functions where the operation has a corresponding service.
7. Important operations create audit records.

### Paired station

1. An owner creates a station and chooses its capability list, handling mode (`kds`, `printed_tickets`, `both`), optional location, and optional printer.
2. The owner issues a pairing code.
3. The station device submits the code to `POST /api/stations/pair/`.
4. The server consumes the code and returns a random bearer token once.
5. Subsequent station API requests use `Authorization: Bearer <device-token>`.
6. Devices can securely rotate bearer tokens via `POST /api/stations/<station-id>/rotate-token/`.
7. The server hashes the supplied token and resolves an active, non-revoked `PairedDevice` for the URL station ID.
8. Each endpoint checks the station's current capability list and scopes data to its business and, where applicable, location.

### Operational print and KDS dispatch

1. Order line items are routed to stations based on configured product assignments or station kind (kitchen vs bar).
2. When an order transitions to `preparing` (or upon payment confirmation in `after_paid` workflows), preparation ticket print jobs are generated idempotently for stations configured for print.
3. Preparation tickets remain distinct from customer receipts and display item quantities, table identifiers, fulfillment types, order timestamps, and instructions.
4. Stations poll or query pending print jobs via `GET /api/stations/<station-id>/print-jobs/` and acknowledge completion or failure via `POST .../ack/`.
5. Stations and Management support controlled ticket reprinting via `reprint_order_ticket`.
6. Stations can display live operational order queues via `/app/<slug>/stations/<station-id>/screen/`.

### Payment provider callbacks and release

1. Payment transactions are created per business through Midtrans or BCA SNAP QRIS Dynamic adapters with strict 10-minute expiry.
2. Provider webhook notifications are received at `POST /api/payments/webhooks/<provider>/`.
3. Signatures are verified using provider-specific algorithms (Midtrans SHA-512; BCA ASPI SNAP symmetric HMAC-SHA512).
4. Replay attacks are prevented using append-only SHA-256 request digests in `PaymentWebhookEvent`.
5. On confirmed payment, the order is released (`after_paid`), transitioning from `new` to `preparing` and dispatching operational preparation tickets.

## 4. Tenant boundaries

`Business` is the tenant root. Catalog, customers, locations, inventory, orders, stations, printers, print jobs, payment connections, payment transactions, and operational events are related to a business. Service and view code must derive the tenant from the authenticated membership or paired-device record, not trust a client-supplied business identifier.

The current Management collaborator permission model is business-wide. The schema contains `Department`, `Workspace`, and `WorkspaceAssignment`, but those records are not currently used as authorization grants.

## 5. ASGI and WebSockets

`config/asgi.py` composes Django's HTTP application with Channels routing. The WebSocket route is:

```text
ws/business/<slug:slug>/orders/
```

`BusinessOrdersConsumer` requires an authenticated user and checks active business membership with `orders.view` (or canonical ownership) before joining the business-specific group.

## 6. Architectural limitations

- The codebase is not split into independently deployed microservices.
- The current WebSocket consumer handles order updates; it is not a universal event bus for every business domain.
- Live Redis/WebSocket delivery must be verified against target staging/production Redis infrastructure.
- MFA/passkeys remain planned.
- Recipe-based stock deduction and billing models remain planned.
