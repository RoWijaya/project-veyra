# Security and authorization

## Security model summary

Veyra has three distinct access contexts:

1. **Canonical business owner** — the user referenced by `Business.owner`.
2. **Management collaborator** — an optional authenticated user with explicit business-level permission strings in `Membership.permissions`.
3. **Paired station device** — a device authenticated by a bearer token and limited by the station's capability allowlist and business/location scope.

A workspace selection or workspace assignment is not an authorization grant.

## User authentication

- Custom `User` uses unique email as `USERNAME_FIELD`.
- Django password validators are configured: similarity, minimum length, common password, and numeric password checks.
- Registration email verification is represented by `email_verified_at`.
- Django password-reset views are configured.
- Session cookies are HttpOnly and SameSite=Lax; in non-debug mode, session and CSRF cookies are Secure and HTTPS redirect is enabled.
- MFA/passkeys are not implemented in the inspected code.

## Management permissions

`Membership.permissions` is an explicit JSON list. `Membership.allows()` grants canonical owners access and checks exact permission strings for collaborators.

Known permission strings include:

- `catalog.view`, `catalog.manage`
- `orders.view`, `orders.create`, `orders.manage`
- `locations.view`, `locations.manage`
- `customers.view`, `customers.manage`
- `inventory.view`, `inventory.manage`
- `employees.view`, `employees.manage`

Collaborators cannot grant permissions they do not themselves hold; the owner can grant supported permissions. The current model is business-wide, not location- or workspace-scoped.

## Station authentication

- Pairing codes are random and stored as SHA-256 digests.
- Codes expire after five minutes and are single-use.
- Pairing returns a random bearer token once; only its digest is stored.
- Pairing attempts are rate-limited by source IP through Django cache.
- Device requests must include an Authorization Bearer token.
- The device lookup binds the token to the station ID in the URL and requires a non-revoked device and active station.
- Capability checks happen server-side.
- Owner can revoke paired devices; disabled stations stop authenticating.
- Paired devices can renew/rotate their bearer token via `POST /api/stations/<station-id>/rotate-token/`; the old token is invalidated immediately upon generation of the new token digest.
- Device fingerprinting is not used as an authentication factor.

Treat bearer tokens as secrets and use TLS for all device traffic.

## Payment credential storage and webhook security

- Payment connections are unique per business/provider.
- Only the canonical owner can manage the connection through service-level checks.
- Credential bundles are encrypted using Fernet authenticated encryption.
- A stable `PAYMENT_CREDENTIALS_ENCRYPTION_KEY` is required.
- Credentials should never be logged, placed in audit metadata, committed to Git, or sent to the browser.
- Connection verification tests credential format against provider adapters and records `verified_at`.
- Webhook endpoints enforce rate limiting, signature verification (Midtrans SHA-512, BCA SNAP HMAC-SHA512), and replay protection using append-only request digests in `PaymentWebhookEvent`.
- Orders release only upon provider-verified settlement (`after_paid`). Browser redirects are never trusted as proof of payment.

## HTTP security controls

The settings include Django CSRF middleware, clickjacking protection, security middleware, and a custom middleware that sets Content-Security-Policy, Permissions-Policy, and Referrer-Policy. In non-debug mode, the configuration enables HTTPS redirect, secure cookies, HSTS for one hour with subdomains, content-type nosniff, and WhiteNoise.

The CSP currently allows scripts from `self` and `cdn.jsdelivr.net`, permits same-origin and `ws:`/`wss:` connections, and disallows objects and framing. Review the policy against the deployed asset and script requirements before production.

## Security gaps / cautions

- MFA/passkeys are not implemented.
- No formal external penetration test is evidenced by this archive.
- Workspace/location-specific collaborator authorization is not implemented; collaborator permissions remain business-wide.
- Ownership transfer is not implemented.
- Rate limiting depends on cache configuration; verify the production Redis cache is active and correctly protected.
- Production secrets and Redis/PostgreSQL network exposure must be controlled by deployment configuration.
- The project should undergo security review and end-to-end tests against production-like PostgreSQL and Redis before handling real transactions.
